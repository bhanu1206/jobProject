// import React, { useEffect, useState } from "react";
// import axiosConfig from "../axiosconfig";
// import { Modal, Button, Form } from "react-bootstrap";

// const JobPosting = () => {
//   const [jobData, setJobData] = useState([]);
//   const [filter, setFilter] = useState("all");
//   const [showModal, setShowModal] = useState(false);
//   const [companyDetails, setCompanyDetails] = useState({
//     companyID: "",
//     companyName: "",
//     companyLocation: "",
//     companyWebsite: ""
//   });

//   useEffect(() => {
//     axiosConfig.get("/api/getAll")
//       .then((response) => {
//         setJobData(response.data);
//       })
//       .catch((error) => {
//         console.error("There was an error fetching the job postings!", error);
//       });
//   }, []);

//   const filteredJobs = jobData.flatMap(company =>
//     company.jobPostings.filter(job => {
//       const today = new Date();
//       const endDate = new Date(job.endDate);
//       const startDate = new Date(job.startDate);

//       if (filter === "active" && today >= startDate && today <= endDate) {
//         return true;
//       } else if (filter === "readyToPost" && today < startDate) {
//         return true;
//       } else if (filter === "expired" && today > endDate) {
//         return true;
//       } else if (filter === "all") {
//         return true;
//       }
//       return false;
//     }).map(job => ({
//       ...job,
//       companyName: company.companyName,
//       companyLocation: company.companyLocation,
//       companyWebsite: company.companyWebsite
//     }))
//   );

//   const handleFilterChange = (newFilter) => {
//     setFilter(newFilter);
//   };

//   const handleModalClose = () => setShowModal(false);
//   const handleModalShow = () => setShowModal(true);

//   const handleRegister = () => {
//     axiosConfig.post("/api/registerCompany", companyDetails)
//       .then(response => {
//         console.log("Company registered successfully", response.data);
//         handleModalClose();
//       })
//       .catch(error => {
//         console.error("There was an error registering the company!", error);
//       });
//   };

//   const handleChange = (e) => {
//     const { name, value } = e.target;
//     setCompanyDetails(prevState => ({ ...prevState, [name]: value }));
//   };

//   return (
//     <div className="container-fluid mt-4">
//       <div className="row">
//         <div className="col-md-3">
//           <div className="list-group">
//             <button
//               className={`list-group-item list-group-item-action ${filter === "active" ? "active" : ""}`}
//               onClick={() => handleFilterChange("active")}
//             >
//               Currently Active
//             </button>
//             <button
//               className={`list-group-item list-group-item-action ${filter === "readyToPost" ? "active" : ""}`}
//               onClick={() => handleFilterChange("readyToPost")}
//             >
//               Ready to Post
//             </button>
//             <button
//               className={`list-group-item list-group-item-action ${filter === "expired" ? "active" : ""}`}
//               onClick={() => handleFilterChange("expired")}
//             >
//               Expired Posts
//             </button>
//             <button
//               className={`list-group-item list-group-item-action ${filter === "all" ? "active" : ""}`}
//               onClick={() => handleFilterChange("all")}
//             >
//               Show All
//             </button>
//           </div>
//         </div>

//         <div className="col-md-9">
//           <div className="d-flex justify-content-between mb-3">
//             <h4>Job Postings</h4>
//             <Button variant="secondary" onClick={handleModalShow}>
//               Post a Job
//             </Button>
//           </div>
//           <table className="table table-bordered">
//             <thead className="table-secondary">
//               <tr>
//                 <th>Job Role</th>
//                 <th>Company Name</th>
//                 <th>Location</th>
//                 <th>Website</th>
//                 <th>Job Type</th>
//                 <th>Experience</th>
//                 <th>Skills</th>
//                 <th>Salary</th>
//                 <th>Created On</th>
//               </tr>
//             </thead>
//             <tbody>
//               {filteredJobs.sort((a, b) => new Date(b.createdOn) - new Date(a.createdOn)).map((job, index) => (
//                 <tr key={index}>
//                   <td>{job.jobRole}</td>
//                   <td>{job.companyName}</td>
//                   <td>{job.jobLocation}</td>
//                   <td><a href={job.companyWebsite} target="_blank" rel="noopener noreferrer">{job.companyWebsite}</a></td>
//                   <td>{job.jobType}</td>
//                   <td>{job.experience}</td>
//                   <td>{job.skills}</td>
//                   <td>{job.salary}</td>
//                   <td>{job.createdOn}</td>
//                 </tr>
//               ))}
//             </tbody>
//           </table>
//         </div>
//       </div>

//       {/* Modal for Company Registration */}
//       <Modal show={showModal} onHide={handleModalClose}>
//         <Modal.Header closeButton>
//           <Modal.Title>Register Your Company</Modal.Title>
//         </Modal.Header>
//         <Modal.Body>
//           <Form>
//             <Form.Group controlId="formCompanyID">
//               <Form.Label>Company ID</Form.Label>
//               <Form.Control
//                 type="text"
//                 name="companyID"
//                 value={companyDetails.companyID}
//                 onChange={handleChange}
//               />
//             </Form.Group>
//             <Form.Group controlId="formCompanyName" className="mt-3">
//               <Form.Label>Company Name</Form.Label>
//               <Form.Control
//                 type="text"
//                 name="companyName"
//                 value={companyDetails.companyName}
//                 onChange={handleChange}
//               />
//             </Form.Group>
//             <Form.Group controlId="formCompanyLocation" className="mt-3">
//               <Form.Label>Company Location</Form.Label>
//               <Form.Control
//                 type="text"
//                 name="companyLocation"
//                 value={companyDetails.companyLocation}
//                 onChange={handleChange}
//               />
//             </Form.Group>
//             <Form.Group controlId="formCompanyWebsite" className="mt-3">
//               <Form.Label>Company Website</Form.Label>
//               <Form.Control
//                 type="text"
//                 name="companyWebsite"
//                 value={companyDetails.companyWebsite}
//                 onChange={handleChange}
//               />
//             </Form.Group>
//           </Form>
//         </Modal.Body>
//         <Modal.Footer>
//           <Button variant="secondary" onClick={handleModalClose}>
//             Close
//           </Button>
//           <Button variant="primary" onClick={handleRegister}>
//             Register
//           </Button>
//         </Modal.Footer>
//       </Modal>
//     </div>
//   );
// };

// export default JobPosting;


import React, { useEffect, useState } from "react";
import axiosConfig from "../axiosconfig";
import { Modal, Button, Form } from "react-bootstrap";
import { useNavigate } from "react-router-dom";

const JobPosting = () => {
  const [jobData, setJobData] = useState([]);
  const [filter, setFilter] = useState("all");
  const [showRegisterModal, setShowRegisterModal] = useState(false);
  const [showPostJobModal, setShowPostJobModal] = useState(false);
  const [showSuccessMessage, setShowSuccessMessage] = useState(false);
  const [companyDetails, setCompanyDetails] = useState({
    companyID: "",
    companyName: "",
    companyLocation: "",
    companyWebsite: ""
  });
  const [jobDetails, setJobDetails] = useState({
    jobRole: "",
    companySize: "",
    jobType: "",
    experience: "",
    jobLocation: "",
    noOfOpenings: "",
    jobShift: "",
    jobDescription: "",
    skills: "",
    rolesAndResponsibilities: "",
    educationLevel: "",
    salary: "",
    startDate: "",
    endDate: "",
    company: {
      companyID: ""
    }
  });

  const navigate = useNavigate();
  useEffect(() => {
    axiosConfig.get("/getAll")
      .then((response) => {
        setJobData(response.data);
      })
      .catch((error) => {
        console.error("There was an error fetching the job postings!", error);
      });
  }, []);

  const filteredJobs = jobData.flatMap(company =>
    company.jobPostings.filter(job => {
      const today = new Date();
      const endDate = new Date(job.endDate);
      const startDate = new Date(job.startDate);

      if (filter === "active" && today >= startDate && today <= endDate) {
        return true;
      } else if (filter === "readyToPost" && today < startDate) {
        return true;
      } else if (filter === "expired" && today > endDate) {
        return true;
      } else if (filter === "all") {
        return true;
      }
      return false;
    }).map(job => ({
      ...job,
      companyName: company.companyName,
      companyLocation: company.companyLocation,
      companyWebsite: company.companyWebsite
    }))
  );

  const handleFilterChange = (newFilter) => {
    setFilter(newFilter);
  };

  const handleRegisterModalClose = () => setShowRegisterModal(false);
  const handleRegisterModalShow = () => setShowRegisterModal(true);

  const handlePostJobModalClose = () => setShowPostJobModal(false);
  const handlePostJobModalShow = () => setShowPostJobModal(true);

  const handleRegister = () => {
    axiosConfig.post("/registerCompany", companyDetails)
      .then(response => {
        console.log("Company registered successfully", response.data);
        handleRegisterModalClose();
      })
      .catch(error => {
        console.error("There was an error registering the company!", error);
      });
  };

  const handlePostJob = () => {
    axiosConfig.post("/createJob", jobDetails)
      .then(response => {
        setShowSuccessMessage(true);
        setTimeout(() => {
          setShowSuccessMessage(false);
          navigate("/jobposting"); // Redirect to Job Posting tab
        }, 2000); // Show success message for 2 seconds
      })
      .catch(error => {
        console.error("There was an error posting the job!", error);
      });
  };

  const handleChangeCompany = (e) => {
    const { name, value } = e.target;
    setCompanyDetails(prevState => ({ ...prevState, [name]: value }));
  };

  const handleChangeJob = (e, nestedField = null) => {
    const { name, value } = e.target;

    if (nestedField === 'companyID') {
      // Update nested companyID
      setJobDetails(prevDetails => ({
        ...prevDetails,
        company: {
          ...prevDetails.company,
          companyID: value
        }
      }));
    } else {
      // Handle other fields
      setJobDetails(prevDetails => ({
        ...prevDetails,
        [name]: value
      }));
    }
  };


  return (
    <div className="container-fluid mt-2">
      <div className="row">
        <div className="col-md-2">
          <div className="list-group">
          <button
              className={`list-group-item list-group-item-action ${filter === "all" ? "active" : ""}`}
              onClick={() => handleFilterChange("all")}
            >
              Show All
            </button>
            <button
              className={`list-group-item list-group-item-action ${filter === "active" ? "active" : ""}`}
              onClick={() => handleFilterChange("active")}
            >
              Currently Active
            </button>
            <button
              className={`list-group-item list-group-item-action ${filter === "readyToPost" ? "active" : ""}`}
              onClick={() => handleFilterChange("readyToPost")}
            >
              Ready to Post
            </button>
            <button
              className={`list-group-item list-group-item-action ${filter === "expired" ? "active" : ""}`}
              onClick={() => handleFilterChange("expired")}
            >
              Expired Posts
            </button>
          </div>
        </div>

        <div className="col-md-9">
          <div className="d-flex justify-content-between mb-3">
            <h4>Job Postings</h4>
            <Button className="ml-5" variant="secondary" onClick={handleRegisterModalShow}>
              Post a Job
            </Button>
          </div>
          <table className="table ">
            <thead className="table-secondary">
              <tr>
                <th>Job Role</th>
                <th>Company Name</th>
                <th>Location</th>
                <th>Website</th>
                <th>Job Type</th>
                <th>Experience</th>
                <th>Skills</th>
                <th>Salary</th>
                <th>StartDate</th>
                <th>EndDate</th>
                <th>Created On</th>
              </tr>
            </thead>
            <tbody>
              {filteredJobs.sort((a, b) => new Date(b.createdOn) - new Date(a.createdOn)).map((job, index) => (
                <tr key={index}>
                  <td>{job.jobRole}</td>
                  <td>{job.companyName}</td>
                  <td>{job.jobLocation}</td>
                  <td><a href={job.companyWebsite} target="_blank" rel="noopener noreferrer">{job.companyWebsite}</a></td>
                  <td>{job.jobType}</td>
                  <td>{job.experience}</td>
                  <td>{job.skills}</td>
                  <td>{job.salary}</td>
                  <td>{job.startDate}</td>
                  <td>{job.endDate}</td>
                  <td>{job.createdOn}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Modal for Company Registration */}
      <Modal show={showRegisterModal} onHide={handleRegisterModalClose} size="lg">
        <Modal.Header closeButton style={{color: 'secondary', }}>
          <Modal.Title>Register Your Company</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <Form>
            <Form.Group controlId="formCompanyID">
              <Form.Label>Company ID</Form.Label>
              <Form.Control
                type="text"
                name="companyID"
                value={companyDetails.companyID}
                onChange={handleChangeCompany}
              />
            </Form.Group>
            <Form.Group controlId="formCompanyName" className="mt-3">
              <Form.Label>Company Name</Form.Label>
              <Form.Control
                type="text"
                name="companyName"
                value={companyDetails.companyName}
                onChange={handleChangeCompany}
              />
            </Form.Group>
            <Form.Group controlId="formCompanyLocation" className="mt-3">
              <Form.Label>Company Location</Form.Label>
              <Form.Control
                type="text"
                name="companyLocation"
                value={companyDetails.companyLocation}
                onChange={handleChangeCompany}
              />
            </Form.Group>
            <Form.Group controlId="formCompanyWebsite" className="mt-3">
              <Form.Label>Company Website</Form.Label>
              <Form.Control
                type="text"
                name="companyWebsite"
                value={companyDetails.companyWebsite}
                onChange={handleChangeCompany}
              />
            </Form.Group>
            <Button
              variant="link"
              className="mt-3"
              onClick={() => {
                handleRegisterModalClose();
                handlePostJobModalShow();
              }}
            >
              Already registered? Post Job
            </Button>
          </Form>
        </Modal.Body>
        <Modal.Footer>
          <Button variant="secondary" onClick={handleRegisterModalClose}>
            Close
          </Button>
          <Button variant="primary" onClick={handleRegister}>
            Register
          </Button>
        </Modal.Footer>
      </Modal>

      {/* Modal for Posting a Job */}
      <Modal show={showPostJobModal} onHide={handlePostJobModalClose} size="lg">
        <Modal.Header closeButton>
          <Modal.Title>Post a Job</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <Form>
            <Form.Group controlId="formCompanyID">
              <Form.Label>Company ID</Form.Label>
              <Form.Control
                type="text"
                name="companyID"
                value={jobDetails.company.companyID || ''}  // Access nested companyID
                onChange={(e) => handleChangeJob(e, 'companyID')}
                placeholder="Enter Company ID"
              />
            </Form.Group>
            <Form.Group controlId="formJobRole">
              <Form.Label>Job Role</Form.Label>
              <Form.Control
                type="text"
                name="jobRole"
                value={jobDetails.jobRole}
                onChange={handleChangeJob}
              />
            </Form.Group>
            <Form.Group controlId="formCompanySize" className="mt-3">
              <Form.Label>Company Size</Form.Label>
              <Form.Control
                type="text"
                name="companySize"
                value={jobDetails.companySize}
                onChange={handleChangeJob}
              />
            </Form.Group>
            <Form.Group controlId="formJobType" className="mt-3">
              <Form.Label>Job Type</Form.Label>
              <Form.Control
                type="text"
                name="jobType"
                value={jobDetails.jobType}
                onChange={handleChangeJob}
              />
            </Form.Group>
            <Form.Group controlId="formExperience" className="mt-3">
              <Form.Label>Experience</Form.Label>
              <Form.Control
                type="text"
                name="experience"
                value={jobDetails.experience}
                onChange={handleChangeJob}
              />
            </Form.Group>
            <Form.Group controlId="formJobLocation" className="mt-3">
              <Form.Label>Job Location</Form.Label>
              <Form.Control
                type="text"
                name="jobLocation"
                value={jobDetails.jobLocation}
                onChange={handleChangeJob}
              />
            </Form.Group>
            <Form.Group controlId="formNoOfOpenings" className="mt-3">
              <Form.Label>No. of Openings</Form.Label>
              <Form.Control
                type="number"
                name="noOfOpenings"
                value={jobDetails.noOfOpenings}
                onChange={handleChangeJob}
              />
            </Form.Group>
            <Form.Group controlId="formJobShift" className="mt-3">
              <Form.Label>Job Shift</Form.Label>
              <Form.Control
                type="text"
                name="jobShift"
                value={jobDetails.jobShift}
                onChange={handleChangeJob}
              />
            </Form.Group>
            <Form.Group controlId="formJobDescription" className="mt-3">
              <Form.Label>Job Description</Form.Label>
              <Form.Control
                as="textarea"
                rows={3}
                name="jobDescription"
                value={jobDetails.jobDescription}
                onChange={handleChangeJob}
              />
            </Form.Group>
            <Form.Group controlId="formSkills" className="mt-3">
              <Form.Label>Skills</Form.Label>
              <Form.Control
                type="text"
                name="skills"
                value={jobDetails.skills}
                onChange={handleChangeJob}
              />
            </Form.Group>
            <Form.Group controlId="formRolesAndResponsibilities" className="mt-3">
              <Form.Label>Roles and Responsibilities</Form.Label>
              <Form.Control
                as="textarea"
                rows={3}
                name="rolesAndResponsibilities"
                value={jobDetails.rolesAndResponsibilities}
                onChange={handleChangeJob}
              />
            </Form.Group>
            <Form.Group controlId="formEducationLevel" className="mt-3">
              <Form.Label>Education Level</Form.Label>
              <Form.Control
                type="text"
                name="educationLevel"
                value={jobDetails.educationLevel}
                onChange={handleChangeJob}
              />
            </Form.Group>
            <Form.Group controlId="formSalary" className="mt-3">
              <Form.Label>Salary</Form.Label>
              <Form.Control
                type="text"
                name="salary"
                value={jobDetails.salary}
                onChange={handleChangeJob}
              />
            </Form.Group>
            <Form.Group controlId="formStartDate" className="mt-3">
              <Form.Label>Start Date</Form.Label>
              <Form.Control
                type="date"
                name="startDate"
                value={jobDetails.startDate}
                onChange={handleChangeJob}
              />
            </Form.Group>
            <Form.Group controlId="formEndDate" className="mt-3">
              <Form.Label>End Date</Form.Label>
              <Form.Control
                type="date"
                name="endDate"
                value={jobDetails.endDate}
                onChange={handleChangeJob}
              />
            </Form.Group>
          </Form>
        </Modal.Body>
        <Modal.Footer>
          <Button variant="secondary" onClick={handlePostJobModalClose}>
            Close
          </Button>
          <Button variant="primary" onClick={handlePostJob}>
            Post
          </Button>
        </Modal.Footer>
      </Modal>
    </div>
  );
};

export default JobPosting;

