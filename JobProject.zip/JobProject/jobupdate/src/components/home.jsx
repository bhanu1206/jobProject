import React from "react";
import { Link } from "react-router-dom";
import JobPosting from "./jobposting";
import JobSearch from "./jobsearch";
import { useState } from "react";

export const Home = () => {
  const [activeTab, setActiveTab] = useState("");

  return (
    <div className="bg-image"
    style={{
      //backgroundImage: "url('https://media.licdn.com/dms/image/D5612AQHmWpsKqCEUgQ/article-cover_image-shrink_600_2000/0/1692110377639?e=2147483647&v=beta&t=61b3z7n63D8ABJOVLQKG4W6iObvwTBn-ZuMabStZugM')",
      height: "100vh",
      backgroundAttachment: "fixed", 
      backgroundPosition: "center",
      backgroundSize: "cover", 
      overflowY: "auto" 
    }}>
      
      <ul className="nav nav-tabs nav-pills" >
        <li className="nav-item">
          <button
            className={`nav-link ${activeTab === "jobposting" ? "active" : ""}`}
            onClick={() => setActiveTab("jobposting")}
          >
            Job Posting
          </button>
        </li>
        <li className="nav-item">
          <button
            className={`nav-link ${activeTab === "jobsearch" ? "active" : ""}`}
            onClick={() => setActiveTab("jobsearch")}
          >
            Job Search
          </button>
        </li>
      </ul>

      <div className="tab-content">
        {activeTab === "jobposting" && <JobPosting />}
        {activeTab === "jobsearch" && <JobSearch />}
      </div>
    </div>
  );
};
