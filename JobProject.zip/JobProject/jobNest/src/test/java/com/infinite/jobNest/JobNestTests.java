package com.infinite.jobNest;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JobNestTests {

	@Test
	void contextLoads() {
	}

}
