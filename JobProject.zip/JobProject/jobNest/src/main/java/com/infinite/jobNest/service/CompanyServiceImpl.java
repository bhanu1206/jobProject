package com.infinite.jobNest.service;

import com.infinite.jobNest.model.Company;
import com.infinite.jobNest.repository.ICompanyRepository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class CompanyServiceImpl implements ICompanyService {

	@Autowired
	private ICompanyRepository companyRepository;

	@Override
	public Company createCompany(Company company) {
		return companyRepository.save(company);
	}

	@Override
	public List<Company> getAllCompanies() {
		return companyRepository.findAll();
	}

//    @Override
//    public Company updateCompany(Long id, Company company) {
//        Optional<Company> existingCompany = companyRepository.findById(id);
//        if (existingCompany.isPresent()) {
//     } else {
//            return null; // Or throw an exception
//        }
//    }

//    @Override
//    public Company getCompanyById(Long id) {
//        return companyRepository.findById(id).orElse(null);
//    }

//    @Override
//    public void deleteCompany(Long id) {
//        companyRepository.deleteById(id);
//    }          Company updatedCompany = existingCompany.get();
//            updatedCompany.setCompanyName(company.getCompanyName());
//            updatedCompany.setCompanyLocation(company.getCompanyLocation());
//            updatedCompany.setCompanyWebsite(company.getCompanyWebsite());
//            return companyRepository.save(updatedCompany);
//     
}
