package com.infinite.jobNest.model;



import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonManagedReference;

import jakarta.persistence.*;

@Entity
@Table(name = "company")
public class Company {

    @Id
    @Column(name = "company_ID")
    private Long companyID;  // Provided by the user from the frontend

    private String companyName;
    private String companyLocation;
    private String companyWebsite;

   
    
    @OneToMany(mappedBy = "company", cascade = CascadeType.ALL, orphanRemoval = true)
    @JsonIgnoreProperties("company") // Avoid infinite recursion
    @JsonManagedReference
    private List<JobParameters> jobParameters;

   

    public Long getCompanyID() {
        return companyID;
    }

    public void setCompanyID(Long companyID) {
        this.companyID = companyID;
    }

    public String getCompanyName() {
        return companyName;
    }

    public void setCompanyName(String companyName) {
        this.companyName = companyName;
    }

    public String getCompanyLocation() {
        return companyLocation;
    }

    public void setCompanyLocation(String companyLocation) {
        this.companyLocation = companyLocation;
    }

    public String getCompanyWebsite() {
        return companyWebsite;
    }

    public void setCompanyWebsite(String companyWebsite) {
        this.companyWebsite = companyWebsite;
    }

    public List<JobParameters> getJobPostings() {
        return jobParameters;
    }

    public void setJobPostings(List<JobParameters> jobParameters) {
        this.jobParameters = jobParameters;
    }
}

