package com.infinite.jobNest.service;


import java.util.List;

import com.infinite.jobNest.model.Company;

public interface ICompanyService {
    Company createCompany(Company company);
//    Company updateCompany(Long id, Company company);
//    Company getCompanyById(Long id);
    List<Company> getAllCompanies();
//    void deleteCompany(Long id);
}
