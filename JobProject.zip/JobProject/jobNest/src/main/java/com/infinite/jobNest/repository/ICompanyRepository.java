package com.infinite.jobNest.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import com.infinite.jobNest.model.Company;

@Repository
public interface ICompanyRepository extends JpaRepository<Company, Long> {

}
