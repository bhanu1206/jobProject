package com.infinite.jobNest.service;

import com.infinite.jobNest.model.JobParameters;

import java.util.List;

public interface IJobParametersService {
	JobParameters createJobParameters(JobParameters JobParameters);
    //JobParameters updateJobParameters(Long id, JobParameters JobParameters);
    JobParameters getJobParametersById(Long id);
    List<JobParameters> getActiveJobParameters();
    void deleteJobParameters(Long id);
}
