package com.infinite.jobNest.service;



import com.infinite.jobNest.model.Company;
import com.infinite.jobNest.model.JobParameters;
import com.infinite.jobNest.repository.IJobParametersRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;
import com.infinite.jobNest.repository.ICompanyRepository;

@Service
public class JobParametersServiceImpl implements IJobParametersService {

    @Autowired
    private IJobParametersRepository jobParametersRepository;
   
    @Autowired
    private ICompanyRepository companyRepository;

    @Override
    public JobParameters createJobParameters(JobParameters jobParameters) {
    	Long companyId = jobParameters.getCompany().getCompanyID();
    	Company company = companyRepository.findById(companyId)
    		    .orElseThrow(() -> new RuntimeException("Company not found with ID: " + companyId));
    	jobParameters.setCompany(company);
        return jobParametersRepository.save(jobParameters);
    }

//    @Override
//    public JobParameters updateJobParameters(Long id, JobParameters jobParameters) {
//        Optional<JobParameters> existingJobParameters = jobParameters.findById(id);
//        if (existingJobParameters.isPresent()) {
//            JobParameters updatedJobParameters = existingJobParameters.get();
//            updatedJobParameters.setJobRole(jobParameters.getJobRole());
//            updatedJobParameters.setCompanyName(jobParameters.getCompanyName());
//            updatedJobParameters.setCompanyDescription(jobParameters.getCompanyDescription());
//            updatedJobParameters.setCompanySize(jobParameters.getCompanySize());
//            updatedJobParameters.setCompanyLocation(jobParameters.getCompanyLocation());
//            updatedJobParameters.setJobType(jobParameters.getJobType());
//            updatedJobParameters.setExperience(jobParameters.getExperience());
//            updatedJobParameters.setJobLocation(jobParameters.getJobLocation());
//            updatedJobParameters.setNoOfOpenings(jobParameters.getNoOfOpenings());
//            updatedJobParameters.setJobShift(jobParameters.getJobShift());
//            updatedJobParameters.setJobDescription(jobParameters.getJobDescription());
//            updatedJobParameters.setSkills(jobParameters.getSkills());
//            updatedJobParameters.setRolesAndResponsibilities(jobParameters.getRolesAndResponsibilities());
//            updatedJobParameters.setEducationLevel(jobParameters.getEducationLevel());
//            updatedJobParameters.setSalary(jobParameters.getSalary());
//            updatedJobParameters.setStartDate(jobParameters.getStartDate());
//            updatedJobParameters.setEndDate(jobParameters.getEndDate());
//            return jobParameters.save(updatedJobParameters);
//        } else {
//            return null; // Or throw an exception
//        }
//    }

    @Override
    public JobParameters getJobParametersById(Long id) {
        return jobParametersRepository.findById(id).orElse(null);
    }

    @Override
    public List<JobParameters> getActiveJobParameters() {
        return jobParametersRepository.findActiveJobParameters(LocalDate.now());
    }

    @Override
    public void deleteJobParameters(Long id) {
    	jobParametersRepository.deleteById(id);
    }


}

