package com.infinite.jobNest.repository;

import com.infinite.jobNest.model.JobParameters;

import java.time.LocalDate;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

@Repository
public interface IJobParametersRepository extends JpaRepository<JobParameters, Long> {
	
	 @Query("SELECT jp FROM JobParameters jp WHERE jp.endDate >= :currentDate")
	    List<JobParameters> findActiveJobParameters(@Param("currentDate") LocalDate currentDate);
	}
